// Sloganlar
let sloganlar = [ 
    "Nerede Diye Sorma, Aç Kapıyı Kargo!",
    "Aras mı? Değil, Aç Kapıyı Kargo!",
    "Takip Bizden, Huzur Sizden.",
    "Dakik ve Güvenli Kargo Burada.",
    "Yolda değil, kapında!"
  ];
  
  let index = 0;
  setInterval(() => {
    document.querySelector(".slogan-text").textContent = sloganlar[index];
    index++;
    if (index >= sloganlar.length) index = 0;
  }, 2000);
  
  // Kullanıcı listesi
  const users = [
    { username: "demo", password: "1234", orders: ["123456 - Yurtiçi", "789012 - MNG"] }
  ];
  
  // Tema değiştirme
  document.getElementById("toggleTheme").addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    const btn = document.getElementById("toggleTheme");
    btn.textContent = document.body.classList.contains("dark-mode") ? "☀️ Açık Mod" : "🌙 Koyu Mod";
  });
  
  // Formları göster
  function showForm(id) {
    document.querySelectorAll("form").forEach(f => f.style.display = "none");
    document.getElementById("statusBox").style.display = "none";
    document.getElementById("previousOrders").style.display = "none";
  
    const form = document.getElementById(id);
    form.style.display = "flex";
  
    setTimeout(() => {
      form.scrollIntoView({ behavior: "smooth" });
    }, 100);
  }
  
  // Giriş işlemi
  function handleLogin(e) {
    e.preventDefault();
    const username = document.getElementById("loginUsername").value;
    const password = document.getElementById("loginPassword").value;
    const user = users.find(u => u.username === username && u.password === password);
  
    if (user) {
      document.getElementById("previousOrders").style.display = "block";
      document.getElementById("orderList").innerHTML = user.orders.map(o => `<li>${o}</li>`).join("");
    } else {
      alert("Kullanıcı bulunamadı.");
    }
  }
  
  // Kayıt işlemi
  function handleRegister(e) {
    e.preventDefault();
    alert("Kayıt başarılı! Giriş yapabilirsiniz.");
    showForm("loginForm");
  }
  
  // Misafir kargo takibi
  function handleGuest(e) {
    e.preventDefault();
    const number = document.getElementById("guestCargoNumber").value;
    const company = document.getElementById("guestCompany").value;
  
    if (number && company) {
      document.getElementById("cargoStatus").innerText = `${number} numaralı kargo: Dağıtıma çıktı 🚚`;
      document.getElementById("statusBox").style.display = "block";
    }
  }
  
  // Menü aç/kapa
  function toggleMenu() {
    const menu = document.getElementById("dropdownMenu");
    const isVisible = menu.style.display === "flex";
  
    menu.style.display = isVisible ? "none" : "flex";
  
    if (!isVisible) {
      document.addEventListener("click", outsideClickListener);
    } else {
      document.removeEventListener("click", outsideClickListener);
    }
  }
  
  // Menü dışına tıklanınca kapat
  function outsideClickListener(event) {
    const menu = document.getElementById("dropdownMenu");
    const icon = document.querySelector(".menu-icon");
  
    if (!menu.contains(event.target) && !icon.contains(event.target)) {
      menu.style.display = "none";
      document.removeEventListener("click", outsideClickListener);
    }
  }
  