<?php
session_start();
$pageTitle = "Ana Sayfa";
?>

<?php include("header.php"); ?>

<main>
  <h1>Hoş Geldiniz</h1>

  <?php if (isset($_SESSION['kullanici'])): ?>
    <p>Merhaba, <strong><?php echo htmlspecialchars($_SESSION['kullanici']); ?></strong>!</p>
    <p><a href="kargolarim.php">Kargolarımı Görüntüle</a></p>
    <p><a href="logout.php">Çıkış Yap</a></p>
  <?php else: ?>
    <p>Giriş yapmadınız. <a href="login.php">Giriş yap</a> veya <a href="register.php">Kayıt ol</a>.</p>
  <?php endif; ?>
</main>

<?php include("footer.php"); ?>

