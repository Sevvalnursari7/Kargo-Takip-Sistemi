<?php
$host = "localhost";
$kullanici = "root";
$sifre = "Tuana4321.";
$veritabani = "websitem";


$conn = new mysqli($host, $kullanici, $sifre, $veritabani);

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}
?>
