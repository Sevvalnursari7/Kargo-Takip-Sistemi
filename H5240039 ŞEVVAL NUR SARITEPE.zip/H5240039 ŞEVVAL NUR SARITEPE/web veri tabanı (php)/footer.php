<footer>
    <div class="contact">İletişim: +90 555 555 55 55</div>
    <p>&copy; 2025 Kargo Takip Sistemi</p>
  </footer>
  <script src="script.js"></script>
</body>
</html>