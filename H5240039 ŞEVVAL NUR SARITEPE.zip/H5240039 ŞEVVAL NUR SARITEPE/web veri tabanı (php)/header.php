<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo isset($pageTitle) ? $pageTitle : 'Kargo Takip'; ?></title>
  <link rel="shortcut icon" href="resim/üstkargologo.jpeg" type="image/x-icon">
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body>
  <header>
    <div class="logo">
      <img src="resim/kargologo.jpeg" alt="Logo">
    </div>
   

    <!-- Menünün tek ve doğru hali -->
    <nav class="dropdown-menu" id="dropdownMenu">
      <a href="anasayfa.php">Ana Sayfa</a>
      <?php if (isset($_SESSION['kullanici'])): ?>
        <a href="hesabim.php">Hesabım</a>
        <a href="logout.php">Çıkış Yap</a>
      <?php else: ?>
        <a href="login.php">Giriş Yap</a>
        <a href="register.php">Kayıt Ol</a>
      <?php endif; ?>
    </nav>

    <button id="toggleTheme">🌙</button>
  </header>
