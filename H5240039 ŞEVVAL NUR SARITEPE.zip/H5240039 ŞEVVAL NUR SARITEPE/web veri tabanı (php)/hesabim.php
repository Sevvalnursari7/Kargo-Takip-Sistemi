<?php
session_start();
include 'baglanti.php';

if (!isset($_SESSION['kullanici'])) {
    header("Location: login.php");
    exit();
}

$kullanici_adi = $_SESSION['kullanici'];

// Kullanıcı ID'sini al
$sql = "SELECT id FROM kullanicilar WHERE kullanici_adi = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $kullanici_adi);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$kullanici_id = $row['id'];

// Kargo ekleme işlemi
$eklemeMesaji = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kargo_no'], $_POST['sirket'], $_POST['durum'])) {
    $kargo_no = trim($_POST['kargo_no']);
    $sirket = trim($_POST['sirket']);
    $durum = trim($_POST['durum']);

    if ($kargo_no === '' || $sirket === '' || $durum === '') {
        $eklemeMesaji = '<div class="error">Lütfen tüm alanları doldurun.</div>';
    } else {
        // Kargoyu ekle
        $ekleSql = "INSERT INTO kargolar (kargo_no, sirket, durum, kullanici_id) VALUES (?, ?, ?, ?)";
        $stmtEkle = $conn->prepare($ekleSql);
        $stmtEkle->bind_param("sssi", $kargo_no, $sirket, $durum, $kullanici_id);
        if ($stmtEkle->execute()) {
            header("Location: hesabim.php");
            exit();
        } else {
            $eklemeMesaji = '<div class="error">Kargo eklenirken hata oluştu.</div>';
        }
    }
}

// Kargoları çek
$sqlKargolar = "SELECT * FROM kargolar WHERE kullanici_id = ?";
$stmtKargolar = $conn->prepare($sqlKargolar);
$stmtKargolar->bind_param("i", $kullanici_id);
$stmtKargolar->execute();
$resultKargolar = $stmtKargolar->get_result();

$aktifKargolar = [];
$gecmisKargolar = [];

while ($kargo = $resultKargolar->fetch_assoc()) {
    if (strtolower($kargo['durum']) === 'teslim edildi') {
        $gecmisKargolar[] = $kargo;
    } else {
        $aktifKargolar[] = $kargo;
    }
}
?>

<?php include 'header.php'; ?>

<style>
  .container {
    max-width: 700px;
    margin: 30px auto;
    background: #fff;
    padding: 25px 30px;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgb(0 0 0 / 0.1);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }
  h1, h2 {
    color: #333;
  }
  ul {
    list-style: none;
    padding-left: 0;
  }
  ul li {
    padding: 8px 12px;
    background: #f0f0f0;
    margin-bottom: 10px;
    border-radius: 6px;
    font-weight: 600;
  }
  .back-button {
    display: inline-block;
    margin-bottom: 20px;
    color: #007bff;
    text-decoration: none;
    font-weight: 600;
  }
  .back-button:hover {
    text-decoration: underline;
  }
  button#toggleTheme {
    background: #444;
    color: #fff;
    border: none;
    padding: 8px 14px;
    border-radius: 5px;
    cursor: pointer;
    float: right;
    margin-top: -40px;
  }
  .dark-mode button#toggleTheme {
    background: #ddd;
    color: #333;
  }
  /* Kargo Ekle Butonu */
  #kargoEkleBtn {
    background-color: #28a745;
    color: white;
    border: none;
    padding: 12px 20px;
    border-radius: 7px;
    cursor: pointer;
    font-weight: 600;
    margin: 20px 0;
    transition: background-color 0.3s ease;
  }
  #kargoEkleBtn:hover {
    background-color: #218838;
  }
  /* Kargo Ekle Formu */
  #kargoForm {
    display: none;
    margin-top: 20px;
    background: #f9f9f9;
    border: 1px solid #ddd;
    padding: 15px 20px;
    border-radius: 8px;
  }
  #kargoForm input, #kargoForm select {
    width: 100%;
    padding: 10px 12px;
    margin-bottom: 12px;
    border-radius: 5px;
    border: 1px solid #ccc;
    font-size: 1em;
  }
  #kargoForm button[type="submit"] {
    background-color: #007bff;
    border: none;
    color: white;
    padding: 12px 20px;
    font-size: 1em;
    cursor: pointer;
    border-radius: 7px;
    font-weight: 600;
  }
  #kargoForm button[type="submit"]:hover {
    background-color: #0069d9;
  }
  .error {
    color: #cc0000;
    margin-bottom: 10px;
    font-weight: 600;
  }
  /* Responsive */
  @media (max-width: 600px) {
    .container {
      margin: 10px;
      padding: 20px 15px;
    }
    button#toggleTheme {
      float: none;
      margin-top: 0;
      width: 100%;
    }
  }
</style>

<div class="container">
  <a href="kargo.html" class="back-button">← Ana Sayfaya Dön</a>
  <button id="toggleTheme">Koyu/Açık Mod</button>

  <h1>Merhaba, <?php echo htmlspecialchars($kullanici_adi); ?> 👋</h1>

  <h2>Aktif Kargolar</h2>
  <?php if (count($aktifKargolar) > 0): ?>
    <ul>
      <?php foreach ($aktifKargolar as $kargo): ?>
        <li><strong><?php echo htmlspecialchars($kargo['kargo_no']); ?></strong> — <?php echo htmlspecialchars($kargo['sirket']); ?> — <?php echo htmlspecialchars($kargo['durum']); ?></li>
      <?php endforeach; ?>
    </ul>
  <?php else: ?>
    <p>Aktif kargonuz bulunmamaktadır.</p>
  <?php endif; ?>

  <h2>Geçmiş Kargolar</h2>
  <?php if (count($gecmisKargolar) > 0): ?>
    <ul>
      <?php foreach ($gecmisKargolar as $kargo): ?>
        <li><strong><?php echo htmlspecialchars($kargo['kargo_no']); ?></strong> — <?php echo htmlspecialchars($kargo['sirket']); ?> — <?php echo htmlspecialchars($kargo['durum']); ?></li>
      <?php endforeach; ?>
    </ul>
  <?php else: ?>
    <p>Geçmiş kargonuz bulunmamaktadır.</p>
  <?php endif; ?>

  <button id="kargoEkleBtn">Kargo Ekle</button>

  <form id="kargoForm" method="POST" action="hesabim.php">
    <?php echo $eklemeMesaji; ?>
    <input type="text" name="kargo_no" placeholder="Kargo Numarası" required>
    <input type="text" name="sirket" placeholder="Şirket" required>
    <select name="durum" required>
      <option value="" disabled selected>Kargo Durumu Seçin</option>
      <option value="Yolda">Yolda</option>
      <option value="Depoda">Depoda</option>
      <option value="Teslim Edildi">Teslim Edildi</option>
      <option value="Beklemede">Beklemede</option>
    </select>
    <button type="submit">Ekle</button>
  </form>
</div>

<script>
  // Koyu mod toggle
  document.getElementById('toggleTheme').addEventListener('click', function () {
    document.body.classList.toggle('dark-mode');
    if (document.body.classList.contains('dark-mode')) {
      localStorage.setItem('theme', 'dark');
    } else {
      localStorage.setItem('theme', 'light');
    }
  });
  window.addEventListener('DOMContentLoaded', () => {
    if (localStorage.getItem('theme') === 'dark') {
      document.body.classList.add('dark-mode');
    }
  });

  // Kargo Ekle butonu ve form toggle
  const btn = document.getElementById('kargoEkleBtn');
  const form = document.getElementById('kargoForm');
  btn.addEventListener('click', () => {
    if (form.style.display === 'block') {
      form.style.display = 'none';
      btn.textContent = 'Kargo Ekle';
    } else {
      form.style.display = 'block';
      btn.textContent = 'Formu Kapat';
    }
  });
</script>

<?php include 'footer.php'; ?>

