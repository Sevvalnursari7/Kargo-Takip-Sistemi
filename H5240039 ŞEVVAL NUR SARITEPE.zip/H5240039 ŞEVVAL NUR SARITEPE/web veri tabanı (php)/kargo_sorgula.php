<?php
include 'baglanti.php';

$sonuc = ""; // Mesaj değişkeni

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kargoNo = $_POST['kargoNumarasi'];
    $firma = $_POST['firma'];

    $sql = "SELECT * FROM kargolar WHERE kargo_no = '$kargoNo' AND sirket = '$firma'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $veri = $result->fetch_assoc();
        $sonuc = "Kargo Numarası <b>" . htmlspecialchars($kargoNo) . "</b> için durum: <b>" . htmlspecialchars($veri['durum']) . "</b>";
    } else {
        $sonuc = "Kargo bulunamadı.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <title>Kargo Sorgulama Sonucu</title>
    <link rel="stylesheet" href="style.css" />
    <style>
        .sonuc-kutusu {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            max-width: 600px;
            margin: 80px auto;
            text-align: center;
            animation: fadeIn 0.6s ease-in-out;
        }

        .sonuc-kutusu h1 {
            color: #007BFF;
            margin-bottom: 20px;
        }

        .sonuc-kutusu p {
            font-size: 20px;
            color: #333;
        }

        .sonuc-kutusu .not-found {
            color: #cc0000;
            font-weight: bold;
        }

        .sonuc-kutusu a {
            display: inline-block;
            margin-top: 30px;
            padding: 12px 24px;
            background: linear-gradient(90deg, #ffa500, #ff7f00);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s ease;
        }

        .sonuc-kutusu a:hover {
            background: linear-gradient(90deg, #ff9900, #e67300);
            transform: scale(1.05);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="sonuc-kutusu">
        <h1>Kargo Sorgulama Sonucu</h1>

        <?php if ($sonuc): ?>
            <p class="<?php echo $sonuc === "Kargo bulunamadı." ? 'not-found' : ''; ?>">
                <?php echo $sonuc; ?>
            </p>
        <?php else: ?>
            <p>Lütfen formu kullanarak kargo sorgulaması yapınız.</p>
        <?php endif; ?>

        <a href="kargo.html">← Anasayfaya Dön</a>
    </div>
</body>
</html>


