
<?php
session_start();
include 'baglanti.php';

$pageTitle = 'Giriş Yap';
$message = '';
$msgClass = '';

// Eğer kayıt başarılı ise bilgi mesajı göster
if (isset($_GET['basari']) && $_GET['basari'] == 1) {
    $message = 'Kayıt başarılı! Şimdi giriş yapabilirsiniz.';
    $msgClass = 'success';
}

// Giriş kontrolü
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullaniciAdi = trim($_POST['username']);
    $sifre = trim($_POST['password']);

    $sql = "SELECT * FROM kullanicilar WHERE kullanici_adi='" . $conn->real_escape_string($kullaniciAdi) . "' AND sifre='" . $conn->real_escape_string($sifre) . "'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $_SESSION['kullanici'] = $kullaniciAdi;
        header('Location: hesabim.php');
        exit;
    } else {
        $message = 'Kullanıcı adı veya şifre yanlış.';
        $msgClass = 'error';
    }
}
?>

<?php include 'header.php'; ?>

<div class="container">
  <h1>Giriş Yap</h1>

  <?php if (!empty($message)): ?>
    <div class="message <?php echo $msgClass; ?>">
      <?php echo htmlspecialchars($message); ?>
    </div>
  <?php endif; ?>

  <form action="login.php" method="POST">
    <input type="text" name="username" placeholder="Kullanıcı Adı" required>
    <input type="password" name="password" placeholder="Şifre" required>
    <button type="submit">Giriş Yap</button>
  </form>

  <div class="back">
    <a href="register.php">← Hesabın yok mu? Kayıt Ol</a>
  </div>
</div>

<?php include 'footer.php'; ?>

