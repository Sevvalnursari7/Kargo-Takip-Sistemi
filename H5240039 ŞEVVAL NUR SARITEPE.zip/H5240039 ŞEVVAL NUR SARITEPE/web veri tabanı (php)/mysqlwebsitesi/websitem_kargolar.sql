-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: websitem
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `kargolar`
--

DROP TABLE IF EXISTS `kargolar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kargolar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kargo_no` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `sirket` varchar(100) COLLATE utf8mb4_turkish_ci DEFAULT NULL,
  `durum` varchar(255) COLLATE utf8mb4_turkish_ci DEFAULT NULL,
  `tahmini_teslim` date DEFAULT NULL,
  `kargo_boyutu` varchar(20) COLLATE utf8mb4_turkish_ci DEFAULT NULL,
  `kullanici_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kargo_no` (`kargo_no`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kargolar`
--

LOCK TABLES `kargolar` WRITE;
/*!40000 ALTER TABLE `kargolar` DISABLE KEYS */;
INSERT INTO `kargolar` VALUES (1,'123456','Yurtiçi','Yolda',NULL,NULL,1),(2,'789012','MNG','Teslim Edildi',NULL,NULL,1),(3,'345678','Aras','Dağıtımda',NULL,NULL,1),(4,'901234','PTT','Kargo Hazırlanıyor',NULL,NULL,3),(5,'567890','Sürat','Yolda',NULL,'Büyük',3),(6,'112233','Hepsijet','Teslim Edildi',NULL,NULL,3),(7,'445566','Trendyol express','Dağıtımda',NULL,'Büyük',3),(8,'778899','MNG','Yolda',NULL,'Büyük',4),(9,'990011','Yurtiçi','Teslim Edildi',NULL,NULL,4),(10,'223344','Aras','Kargo Hazırlanıyor',NULL,NULL,4),(31,'334455','Yurtiçi','Yolda',NULL,'Büyük',5),(32,'556677','MNG','Teslim Edildi',NULL,NULL,5),(33,'778800','Aras','Dağıtımda',NULL,NULL,5),(34,'990022','PTT','Kargo Hazırlanıyor',NULL,NULL,6),(35,'112244','Sürat','Yolda',NULL,NULL,6),(36,'334466','Hepsijet','Teslim Edildi',NULL,NULL,NULL),(37,'957685','aras','yolda',NULL,NULL,11),(38,'672947','Yurtiçi','Depoda',NULL,'Büyük',14),(57,'349874','Sürat','Yolda',NULL,'Büyük',15);
/*!40000 ALTER TABLE `kargolar` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-03 12:05:51
