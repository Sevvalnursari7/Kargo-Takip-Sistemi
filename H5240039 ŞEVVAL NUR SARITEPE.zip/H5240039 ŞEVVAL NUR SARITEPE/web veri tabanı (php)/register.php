<?php
session_start();
include 'baglanti.php';
$pageTitle = 'Kayıt Ol';
$message = '';
$msgClass = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kullaniciAdi = trim($_POST['username']);
    $sifre = trim($_POST['password']);

    // Aynı kullanıcı adı kontrolü
    $check = $conn->query("SELECT id FROM kullanicilar WHERE kullanici_adi='" . $conn->real_escape_string($kullaniciAdi) . "'");
    if ($check->num_rows > 0) {
        $message = 'Bu kullanıcı adı zaten kullanılıyor. Lütfen başka bir kullanıcı adı deneyin.';
        $msgClass = 'error';
    } else {
        // Kayıt işlemi
        $insert = $conn->query("INSERT INTO kullanicilar (kullanici_adi, sifre) VALUES ('" . $conn->real_escape_string($kullaniciAdi) . "', '" . $conn->real_escape_string($sifre) . "')");
        
        if ($insert) {
            // Otomatik giriş ve yönlendirme
            $_SESSION['kullanici'] = $kullaniciAdi;
            header('Location: hesabim.php');
            exit;
        } else {
            $message = 'Kayıt sırasında hata oluştu. Lütfen tekrar deneyin.';
            $msgClass = 'error';
        }
    }
}
?>

<?php include 'header.php'; ?>

<div class="container">
  <h1>Kayıt Ol</h1>
  <?php if (!empty($message)): ?>
    <div class="message <?php echo $msgClass; ?>"><?php echo htmlspecialchars($message); ?></div>
  <?php endif; ?>
  <form action="register.php" method="POST">
    <input type="text" name="username" placeholder="Kullanıcı Adı" required>
    <input type="password" name="password" placeholder="Şifre" required minlength="6">
    <button type="submit">Kayıt Ol</button>
  </form>
  <div class="back">
    <a href="login.php" class="button-link">← Zaten hesabın var mı? Giriş Yap</a>
  </div>
</div>

<?php include 'footer.php'; ?>
