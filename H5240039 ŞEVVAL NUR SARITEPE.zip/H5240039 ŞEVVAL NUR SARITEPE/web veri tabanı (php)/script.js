console.log("JavaScript dosyası başarıyla yüklendi.");

function showForm(id) {
  // Tüm formları ve sonuç kutularını gizle
  document.querySelectorAll('.form-section').forEach(f => f.style.display = 'none');

  const statusBox = document.getElementById("statusBox");
  if (statusBox) statusBox.style.display = "none";

  const previousOrders = document.getElementById("previousOrders");
  if (previousOrders) previousOrders.style.display = "none";

  // İlgili formu göster
  const form = document.getElementById(id);
  if (form) {
    form.style.display = 'flex';

    // Sayfayı forma kaydır
    setTimeout(() => {
      form.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }
}

function toggleMenu() {
  const menu = document.getElementById("dropdownMenu");
  if (menu) {
    menu.style.display = (menu.style.display === "flex") ? "none" : "flex";
  }
}

// Menüdeki bağlantılara tıklanınca menüyü kapat
document.querySelectorAll(".dropdown-menu a").forEach(link => {
  link.addEventListener("click", () => {
    const menu = document.getElementById("dropdownMenu");
    if (menu) menu.style.display = "none";
  });
});

// Kullanıcı menünün dışına tıklarsa menüyü kapat
window.addEventListener("click", function (e) {
  const menu = document.getElementById("dropdownMenu");
  const button = document.getElementById("dropdownButton"); // Aç/kapat butonu ID'si bu olmalı

  if (menu && !menu.contains(e.target) && (!button || !button.contains(e.target))) {
    menu.style.display = "none";
  }
});
