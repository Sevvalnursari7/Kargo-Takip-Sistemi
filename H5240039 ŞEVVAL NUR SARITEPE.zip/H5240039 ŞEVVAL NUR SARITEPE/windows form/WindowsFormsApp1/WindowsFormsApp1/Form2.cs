﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    public partial class Form2: Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\kargoTakip.mdf;Integrated Security=True");

        private void geriGelBtn_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }

        private void girisYapBtn_Click(object sender, EventArgs e)
        {
            connection.Open();

            SqlCommand komut = new SqlCommand("SELECT * FROM kullanicilar WHERE mail = @mail AND sifre = @sifre", connection);
            komut.Parameters.AddWithValue("@mail", mailTxtbox.Text);
            komut.Parameters.AddWithValue("@sifre", sifreTxtbox.Text);

            SqlDataReader dr = komut.ExecuteReader();

            if (dr.Read())
            {

                Session.KullaniciID = dr["adSoyad"].ToString();

                Form4 frm = new Form4(); 
                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Hatalı mail veya şifre!");
            }

            connection.Close();

        }

        private void sifreTxtbox_TextChanged(object sender, EventArgs e)
        {
            sifreTxtbox.PasswordChar = '*';
        }
    }
}
