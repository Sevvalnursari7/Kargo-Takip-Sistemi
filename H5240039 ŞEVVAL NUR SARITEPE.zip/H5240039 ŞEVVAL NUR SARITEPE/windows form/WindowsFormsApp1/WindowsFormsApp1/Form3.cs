﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\kargoTakip.mdf;Integrated Security=True");

        private void geriGelBtn_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Hide();
        }

        private void girisYapBtn_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }

        private void uyeOlBtn_Click(object sender, EventArgs e)
        {
            connection.Open();

            SqlCommand komut = new SqlCommand("INSERT INTO kullanicilar (adSoyad, mail, sifre) VALUES (@ad, @mail, @sifre)", connection);
            komut.Parameters.AddWithValue("@ad", adSoyadTxtbox.Text);
            komut.Parameters.AddWithValue("@mail", mailTxtbox.Text);
            komut.Parameters.AddWithValue("@sifre", sifreTxtbox.Text);
            komut.ExecuteNonQuery();

            connection.Close();
            MessageBox.Show("Kayıt başarılı!");
            Form2 frm = new Form2();
            frm.Show();
            this.Hide();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            sifreTxtbox.PasswordChar = '*';

        }
    }
}
