﻿namespace WindowsFormsApp1
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.kargoNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kargoSirketDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kargoDurumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kargolarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kargoTakipDataSet = new WindowsFormsApp1.kargoTakipDataSet();
            this.geriGelBtn = new System.Windows.Forms.Button();
            this.kargolarTableAdapter = new WindowsFormsApp1.kargoTakipDataSetTableAdapters.kargolarTableAdapter();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kargolarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kargoTakipDataSet)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kargoNoDataGridViewTextBoxColumn,
            this.kargoSirketDataGridViewTextBoxColumn,
            this.kargoDurumDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.kargolarBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(25, 184);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(431, 208);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // kargoNoDataGridViewTextBoxColumn
            // 
            this.kargoNoDataGridViewTextBoxColumn.DataPropertyName = "KargoNo";
            this.kargoNoDataGridViewTextBoxColumn.HeaderText = "KargoNo";
            this.kargoNoDataGridViewTextBoxColumn.Name = "kargoNoDataGridViewTextBoxColumn";
            this.kargoNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kargoSirketDataGridViewTextBoxColumn
            // 
            this.kargoSirketDataGridViewTextBoxColumn.DataPropertyName = "KargoSirket";
            this.kargoSirketDataGridViewTextBoxColumn.HeaderText = "KargoSirket";
            this.kargoSirketDataGridViewTextBoxColumn.Name = "kargoSirketDataGridViewTextBoxColumn";
            this.kargoSirketDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kargoDurumDataGridViewTextBoxColumn
            // 
            this.kargoDurumDataGridViewTextBoxColumn.DataPropertyName = "KargoDurum";
            this.kargoDurumDataGridViewTextBoxColumn.HeaderText = "KargoDurum";
            this.kargoDurumDataGridViewTextBoxColumn.Name = "kargoDurumDataGridViewTextBoxColumn";
            this.kargoDurumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // kargolarBindingSource
            // 
            this.kargolarBindingSource.DataMember = "kargolar";
            this.kargolarBindingSource.DataSource = this.kargoTakipDataSet;
            // 
            // kargoTakipDataSet
            // 
            this.kargoTakipDataSet.DataSetName = "kargoTakipDataSet";
            this.kargoTakipDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // geriGelBtn
            // 
            this.geriGelBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.geriGelBtn.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.geriGelBtn.Location = new System.Drawing.Point(6, 131);
            this.geriGelBtn.Name = "geriGelBtn";
            this.geriGelBtn.Size = new System.Drawing.Size(60, 25);
            this.geriGelBtn.TabIndex = 4;
            this.geriGelBtn.Text = "Geri Git";
            this.geriGelBtn.UseVisualStyleBackColor = false;
            this.geriGelBtn.Click += new System.EventHandler(this.geriGelBtn_Click);
            // 
            // kargolarTableAdapter
            // 
            this.kargolarTableAdapter.ClearBeforeFill = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(484, 125);
            this.panel1.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(334, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 19);
            this.label2.TabIndex = 6;
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(5, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(117, 116);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(484, 421);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.geriGelBtn);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kargolarim";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kargolarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kargoTakipDataSet)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button geriGelBtn;
        private kargoTakipDataSet kargoTakipDataSet;
        private System.Windows.Forms.BindingSource kargolarBindingSource;
        private kargoTakipDataSetTableAdapters.kargolarTableAdapter kargolarTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn kargoNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kargoSirketDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kargoDurumDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
    }
}