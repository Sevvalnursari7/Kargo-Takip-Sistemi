﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    public partial class Form5: Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\kargoTakip.mdf;Integrated Security=True");


        private void geriGelBtn_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            label2.Text = System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Session.KullaniciID.ToLower());
            connection.Open();


            SqlCommand komut = new SqlCommand("SELECT kargoNo, kargoSirket, kargoDurum FROM kargolar WHERE kargoAlici = @alici", connection);
            komut.Parameters.AddWithValue("@alici", Session.KullaniciID);

            SqlDataAdapter da = new SqlDataAdapter(komut);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;

            // Eğer buton kolonu zaten varsa yeniden ekleme
            if (!dataGridView1.Columns.Contains("Detaylar"))
            {
                DataGridViewButtonColumn btnColumn = new DataGridViewButtonColumn();
                btnColumn.HeaderText = "İşlem";
                btnColumn.Text = "Görüntüle";
                btnColumn.Name = "btnGoruntule";
                btnColumn.UseColumnTextForButtonValue = true; // Butonda "Görüntüle" yazsın
                dataGridView1.Columns.Add(btnColumn);
            }

            connection.Close();

            
          
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            {

                if (e.RowIndex >= 0 && e.ColumnIndex == dataGridView1.Columns["btnGoruntule"].Index)
                {
                    string kargoDurum = dataGridView1.Rows[e.RowIndex].Cells["kargoDurumDataGridViewTextBoxColumn"].Value.ToString();

                    // Yeni formu aç
                    KargoDetayForm detayForm = new KargoDetayForm(kargoDurum);
                    detayForm.ShowDialog(); // veya Show()
                }
            }

        }
    }
}
