﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    public partial class Form6: Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\kargoTakip.mdf;Integrated Security=True");

        private void geriGelBtn_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void kargoEkleBtn_Click(object sender, EventArgs e)
        {
            connection.Open();

            SqlCommand komut = new SqlCommand("INSERT INTO kargolar (kargoNo, kargoSirket, kargoDurum, kargoAlici) VALUES (@no, @sirket, @durum, @alici)", connection);
            komut.Parameters.AddWithValue("@no", kargoNoTxtbox.Text);
            komut.Parameters.AddWithValue("@sirket", KargoSirketCombobox.SelectedItem.ToString());
            komut.Parameters.AddWithValue("@durum", kargoDurumCombobox.SelectedItem.ToString());
            komut.Parameters.AddWithValue("@alici", Session.KullaniciID);

            komut.ExecuteNonQuery();
            connection.Close();

            MessageBox.Show("Kargo başarıyla eklendi.");


        }

        private void Form6_Load(object sender, EventArgs e)
        {
            label2.Text = System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Session.KullaniciID.ToLower());

        }
    }
}
