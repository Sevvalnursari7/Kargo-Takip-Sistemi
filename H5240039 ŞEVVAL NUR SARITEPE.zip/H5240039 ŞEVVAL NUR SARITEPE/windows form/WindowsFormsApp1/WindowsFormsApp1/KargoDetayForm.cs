﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class KargoDetayForm: Form
    {

        public KargoDetayForm(string kargoDurum)
        {
            InitializeComponent();
            labelDurum.Text = $"Kargo Durumu: {kargoDurum}";
        }

        private void mesajGonderBtn_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "")
            {
                MessageBox.Show("Mesajınız gönderildi.");
                textBox1.Clear();
            }
            else
            {
                MessageBox.Show("Lütfen mesajınızı girin.");
            }
        }

        private void KargoDetayForm_Load(object sender, EventArgs e)
        {
            label2.Text = System.Globalization.CultureInfo.CurrentCulture.TextInfo.ToTitleCase(Session.KullaniciID.ToLower());

        }
    }
}
